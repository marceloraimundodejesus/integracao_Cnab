package br.com.siscnab.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SistemaCnabApplication {

	public static void main(String[] args) {
		SpringApplication.run(SistemaCnabApplication.class, args);
	}

}
