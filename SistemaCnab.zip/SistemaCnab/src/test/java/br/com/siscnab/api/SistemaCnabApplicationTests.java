package br.com.siscnab.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SistemaCnabApplicationTests {

	@Test
	void contextLoads() {
	}

}
